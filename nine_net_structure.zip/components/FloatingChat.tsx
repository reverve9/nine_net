'use client'

import { useState, useEffect } from 'react'

interface FloatingChatProps {
  user: any
}

export default function FloatingChat({ user }: FloatingChatProps) {
  const [unreadCount, setUnreadCount] = useState(0)
  const [isElectron, setIsElectron] = useState(false)

  useEffect(() => {
    setIsElectron(!!window.electronAPI?.isElectron)
  }, [])

  const handleButtonClick = () => {
    if (isElectron && window.electronAPI) {
      window.electronAPI.toggleMessenger()
    } else {
      // 웹: 새 창으로 메신저 열기 (Electron과 동일 사이즈)
      const width = 400
      const height = 600
      const left = window.screen.width - width - 20
      const top = 80
      window.open(
        '/messenger',
        'messenger',
        `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=no`
      )
    }
  }

  return (
    <>
      {/* 플로팅 버튼 */}
      <button
        onClick={handleButtonClick}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition flex items-center justify-center z-50"
      >
        <span className="text-2xl">💬</span>
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>
    </>
  )
}
